# Grupparbete Studiegrupp 12

## Kaj Berg, Mattis Erkensten, Senad Catovic, Senad Velagic
